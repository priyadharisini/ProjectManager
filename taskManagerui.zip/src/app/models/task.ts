import { DatePipe } from '@angular/common/src/pipes/date_pipe';
export class Task {
  Task_ID: number;
  TaskName: string;
  TaskEnded:boolean;
  StartDate: DatePipe;
  Priority: string;
  ParentTask: string;
  EndDate:DatePipe;
  constructor(
    task_ID: number,
    taskName: string,
    taskEnded:boolean,
    startDate: DatePipe,
    priority: string,
    parentTask: string,
    endDate:DatePipe
  ) {
      this.Task_ID = task_ID;
      this.TaskName = taskName;
      this.TaskEnded = taskEnded;
      this.StartDate = startDate;
      this.Priority = priority;
      this.ParentTask = parentTask;
      this.EndDate = endDate;
  }
}