import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";
import { Task } from 'src/app/models/task';
import { TaskSearch } from 'src/app/models/taskSearch';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  private taskManagerService = "http://localhost/TaskManager/v1/Tasks/addnewTask"
  private getTaskurl = "http://localhost/TaskManager/v1/Tasks/";
  private updateTaskurl = "http://localhost/TaskManager/v1/Tasks/update/";
  private endTaskUrl = "http://localhost/TaskManager/v1/Tasks/end/";
  private searchTaskUrl = "http://localhost/TaskManager/v1/Tasks/search/";

  constructor( private http: HttpClient) { }

  addTaskService(parameter : Task )
  {
        return this.http.post(this.taskManagerService, parameter).pipe();
  }

  getAll(): Observable<Task[]>{
    return this.http.get<Task[]>(this.getTaskurl).pipe();
  }

  getTask(taskid:string):Observable<Task>{    
    return this.http.get<Task>(this.getTaskurl +taskid )
  }

  updateTask(parameter : Task , taskId : string)
  {        return this.http.post(this.updateTaskurl + taskId , parameter).pipe();
  }

  endTask(taskId : string)
  {        return this.http.post(this.endTaskUrl + taskId, '').pipe();            
  }

  searchTask(parameter : TaskSearch)
  {
       return this.http.post(this.searchTaskUrl, parameter).pipe();
  }
}
