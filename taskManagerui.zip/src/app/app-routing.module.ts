import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddComponent } from '../app/ui/add/add.component';
import { EditComponent } from '../app/ui/edit/edit.component';
import { ViewComponent } from '../app/ui/view/view.component';

const routes: Routes = [
  { path: '', component: ViewComponent },
{ path: 'Add', component: AddComponent },
{ path: 'Edit/:taskid', component: AddComponent },
{ path: 'Edit', component: EditComponent },
{ path: 'View', component: ViewComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
