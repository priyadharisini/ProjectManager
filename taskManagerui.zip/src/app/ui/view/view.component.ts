import { Component, OnInit } from '@angular/core';
import {SharedService } from 'src/app/taskservices/shared.service'
import { FormGroup, FormControl } from '@angular/forms'
import { Task } from 'src/app/models/task';
import { TaskSearch } from 'src/app/models/taskSearch';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  constructor( private taskService : SharedService, private router:Router) { }
  getAllTask:any;
  ngOnInit() {
    this.taskService.getAll().subscribe(res => this.getAllTask = res)
  }

  SearchTaskForm = new FormGroup({
    TaskName : new FormControl(""),
    ParentTaskName : new FormControl(""),
    StartDate : new FormControl(""),
    EndDate : new FormControl(""),
    PriorityFrom : new FormControl(""),
    PriorityTo : new FormControl("")
  })

  endTask(taskid){
    this.taskService.endTask(taskid).subscribe();
    this.router.navigate(['/Add']);
  }

  searchTask()
  {
    let taskSearch:TaskSearch = new TaskSearch(
            this.SearchTaskForm.value.TaskName,
            this.SearchTaskForm.value.ParentTaskName,
            this.SearchTaskForm.value.PriorityFrom,
            this.SearchTaskForm.value.PriorityTo,
            this.SearchTaskForm.value.StartDate,
            this.SearchTaskForm.value.EndDate,
            )

      this.taskService.searchTask(taskSearch).subscribe(res => this.getAllTask = res);
  }
}
