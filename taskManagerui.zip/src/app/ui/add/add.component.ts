import { Component, OnInit } from '@angular/core';
import {SharedService } from 'src/app/taskservices/shared.service'
import { FormGroup, FormControl, Validators } from '@angular/forms'
import { Task } from 'src/app/models/task';
import { ActivatedRoute,Router } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css'],
  providers: [DatePipe]
})
export class AddComponent implements OnInit {
  TaskToEdit:Task;
  TaskId:string;
  constructor(     private taskService : SharedService,private router:Router, private route:ActivatedRoute, private datepipe:DatePipe) { }

  TaskForm = new FormGroup({ task : new FormControl("", [Validators.required, Validators.minLength(4)]) , 
  priority : new FormControl(""),
  parentTask : new FormControl(""),
  startDate : new FormControl("", Validators.required),
  endDate : new FormControl("", Validators.required),
 });

  ngOnInit() {
    this.route.params.subscribe( params => this.TaskId = params['taskid'] );  
    if( this.TaskId != undefined)  {
      debugger;
      console.log(this.TaskId);
      this.taskService.getTask(this.TaskId).subscribe( res => this.TaskToEdit =  res, (err)=> console.log(err), ()=>{
        this.TaskForm.setValue({
          task: this.TaskToEdit.TaskName,
          priority: this.TaskToEdit.Priority,
          parentTask: this.TaskToEdit.ParentTask || "Default parent",
          startDate:  this.datepipe.transform(this.TaskToEdit.StartDate, "yyyy-MM-dd"),
          endDate: this.datepipe.transform(this.TaskToEdit.EndDate, "yyyy-MM-dd")
        })
      })
    }
   
  }

  addTask()  {
        console.log("Add task Called");
          let task:Task = new Task(
          0,
          this.TaskForm.value.task,
          false,
          this.TaskForm.value.startDate,
          this.TaskForm.value.priority,
          this.TaskForm.value.parentTask,
          this.TaskForm.value.endDate,
          )
          console.log(task);
          if (this.TaskId != undefined)
          {
            this.taskService.updateTask(task, this.TaskId).subscribe();
          }
          else
          {
            this.taskService.addTaskService(task).subscribe();
          }
          this.router.navigate(['/View']);
      }

    reset() {
      this.TaskForm.reset();
      this.router.navigate(['/View']);
    }

}
